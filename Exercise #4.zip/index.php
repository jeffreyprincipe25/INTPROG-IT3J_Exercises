<?php
// Initialize variables
$name = $role = $desc = $phone = $email = $website = $imagePath = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST["name"]);
    $role = htmlspecialchars($_POST["role"]);
    $desc = htmlspecialchars($_POST["desc"]);
    $phone = htmlspecialchars($_POST["phone"]);
    $email = htmlspecialchars($_POST["email"]);
    $website = htmlspecialchars($_POST["website"]);

    // Handle image upload
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $targetFile = $targetDir . basename($_FILES["image"]["name"]);
        move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile);
        $imagePath = $targetFile;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Our Team</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>

  <h1>Add Team Member</h1>

  <!-- Form Section -->
  <form action="" method="POST" enctype="multipart/form-data">
      <label>Full Name:</label><br>
      <input type="text" name="name" required><br><br>

      <label>Role:</label><br>
      <input type="text" name="role" required><br><br>

      <label>Description:</label><br>
      <textarea name="desc" required></textarea><br><br>

      <label>Phone:</label><br>
      <input type="text" name="phone"><br><br>

      <label>Email:</label><br>
      <input type="email" name="email"><br><br>

      <label>Website:</label><br>
      <input type="text" name="website"><br><br>

      <label>Profile Image:</label><br>
      <input type="file" name="image"><br><br>

      <button type="submit">Add Team Member</button>
  </form>

  <hr>

  <!-- Display Section -->
  <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { ?>
  <h1 class="title">Meet Our Team</h1>
  <div class="team-container">
      <div class="team-card">
          <?php if (!empty($imagePath)) { ?>
              <img src="<?php echo $imagePath; ?>" alt="<?php echo $name; ?>" />
          <?php } ?>
          <h3><?php echo $name; ?></h3>
          <p class="role"><?php echo $role; ?></p>
          <p class="desc"><?php echo $desc; ?></p>
          <p class="contact">
              📞 <?php echo $phone; ?><br>
              📧 <?php echo $email; ?><br>
              🌐 <?php echo $website; ?>
          </p>
      </div>
  </div>
  <?php } ?>

</body>
</html>